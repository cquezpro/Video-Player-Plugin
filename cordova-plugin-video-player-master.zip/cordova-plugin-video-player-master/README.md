cordova-plugin-video-player
===========================

Video player plugin for Cordova/Phonegap 3.0.0+
